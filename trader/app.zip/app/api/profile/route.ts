import { NextResponse } from "next/server";
import { requireUser } from "@/lib/auth/requireUser";

export async function GET() {
    try {
        const user = await requireUser();

        return NextResponse.json(
            {
                success: true,
                data: user,
            },
            { status: 200, }
        );
    }
    catch {
        return NextResponse.json(
            {
                success: false,
                message: "Unauthorized.",
            },
            { status: 401, }
        );
    }
}