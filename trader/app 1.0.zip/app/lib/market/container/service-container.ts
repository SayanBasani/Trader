import { HttpClient } from "../client";
import { FetchAdapter } from "../client/adapters";
import { MARKET_ENV } from "../config/env";

export class ServiceContainer {
    private static httpClient: HttpClient;

    static getHttpClient(): HttpClient {

        if (!this.httpClient) {

            const provider =
                MARKET_ENV.providers[
                    MARKET_ENV.provider
                ];

            this.httpClient = new HttpClient(
                {
                    baseUrl: provider.baseUrl,
                    timeout: provider.timeout,
                    retry: provider.retry,
                },
                new FetchAdapter(),
            );
        }

        return this.httpClient;
    }
}