import { MarketProviderError, MarketRateLimitError } from "./errors";

export async function httpRequest<T>(
    url: string,
    provider: string,
    init?: RequestInit,
): Promise<T> {
    const response = await fetch(url, {
        ...init,
        cache: "no-store",
    });

    if (response.status === 429) {
        throw new MarketRateLimitError(provider);
    }

    if (!response.ok) {
        throw new MarketProviderError(
            response.statusText,
            provider,
            response.status,
        );
    }

    return response.json() as Promise<T>;
}