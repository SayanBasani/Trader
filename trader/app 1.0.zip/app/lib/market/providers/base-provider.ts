import { MarketProvider } from "../interfaces/market-provider";
import { httpRequest } from "../utils/http";
import { AuthStrategy } from "./auth-strategy";

export abstract class BaseMarketProvider implements MarketProvider {
    public abstract readonly name: string;

    protected abstract readonly baseUrl: string;

    protected abstract readonly apiKey: string;

    protected abstract readonly apiKeyParam: string;
    protected abstract readonly authStrategy: AuthStrategy;

    protected abstract readonly authKeyName: string;

    protected async get<T>(
        endpoint: string,
        query: URLSearchParams = new URLSearchParams(),
    ): Promise<T> {
        const url = new URL(endpoint, this.baseUrl);

        const headers = new Headers();

        if (this.authStrategy === AuthStrategy.QUERY) {
            query.set(this.authKeyName, this.apiKey);
        }

        if (this.authStrategy === AuthStrategy.HEADER) {
            headers.set(this.authKeyName, this.apiKey);
        }

        url.search = query.toString();

        return httpRequest<T>(
            url.toString(),
            this.name,
            {
                headers,
            },
        );

        url.search = query.toString();

        return httpRequest<T>(
            url.toString(),
            this.name,
        );
    }

    abstract searchStocks(query: string): Promise<any>;

    abstract getQuote(symbol: string): Promise<any>;

    abstract getCompany(symbol: string): Promise<any>;

    abstract getHistoricalCandles(
        symbol: string,
        resolution: string,
        from: number,
        to: number,
    ): Promise<any>;

    abstract getMarketNews(
        category?: string,
    ): Promise<any>;

    abstract getMarketStatus(
        exchange?: string,
    ): Promise<any>;
}